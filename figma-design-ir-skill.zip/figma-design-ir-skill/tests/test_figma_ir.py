import importlib.util
import json
import pathlib
import tempfile
import unittest

SCRIPT = pathlib.Path(__file__).resolve().parents[1] / 'scripts' / 'figma_ir.py'
spec = importlib.util.spec_from_file_location('figma_ir', SCRIPT)
ir = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ir)


def fixture():
    return {'version':'v1', 'styles':{'S:1':{'name':'Body'}}, 'document':{
        'id':'0:0','type':'DOCUMENT','children':[{'id':'1:1','type':'CANVAS','children':[
            {'id':'1:2','type':'FRAME','layoutMode':'GRID','gridColumnCount':2,
             'layoutSizingHorizontal':'FILL','clipsContent':False,'opacity':0,
             'fills':[{'type':'GRADIENT_LINEAR','gradientStops':[{'position':0.0,'color':{'r':0.1,'g':0.2,'b':0.3,'a':0.4}}]}],
             'boundVariables':{'fills':[{'type':'VARIABLE_ALIAS','id':'VariableID:5'}]},
             'locked':True,'pluginData':{'unused':'secret'},
             'children':[{'id':'1:3','type':'TEXT','characters':'A🙂B','style':{'fontFamily':'Inter','fontSize':13.5},
                 'characterStyleOverrides':[0,3,0], 'styleOverrideTable':{'3':{'fontFamily':'Other'}},
                 'relativeTransform':[[1,0,33],[0,1,44]],'mysteriousFutureRenderingAttribute':{'important':[1,2,3]}}]
            }]}]}}


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.tmp.name)
        self.src = self.root/'in.json'; self.out = self.root/'out'
        self.src.write_text(json.dumps(fixture(), ensure_ascii=False, indent=2), encoding='utf-8')

    def tearDown(self):
        self.tmp.cleanup()

    def test_build_validate_lookup_and_unknown_fields(self):
        ir.build(self.src, self.out)
        self.assertTrue(ir.validate(self.out)['valid'])
        self.assertEqual((self.out/'raw.json').read_bytes(),self.src.read_bytes())
        node = ir.lookup(self.out,'1:3')
        self.assertEqual(node['characterStyleOverrides'],[0,3,0])
        compact=json.loads((self.out/'compact.json').read_text())
        textnode=compact['document']['children'][0]['children'][0]['children'][0]
        self.assertEqual(textnode['mysteriousFutureRenderingAttribute'], {'important':[1,2,3]})
        self.assertEqual(compact['document']['children'][0]['children'][0]['opacity'],0)
        self.assertFalse(compact['document']['children'][0]['children'][0]['clipsContent'])
        self.assertNotIn('locked',compact['document']['children'][0]['children'][0])

    def test_tampering_detected(self):
        ir.build(self.src,self.out)
        with (self.out/'compact.json').open('a') as fp: fp.write(' ')
        with self.assertRaisesRegex(ValueError,'Hash mismatch'): ir.validate(self.out)

    def test_duplicate_ids_rejected(self):
        d=fixture(); d['document']['children'][0]['id']='0:0'
        self.src.write_text(json.dumps(d))
        with self.assertRaisesRegex(ValueError,'Duplicate'): ir.build(self.src,self.out)

    def test_nodes_response_with_missing_id(self):
        d={'version':'v2','nodes':{'1:2':{'document':fixture()['document']['children'][0]},'x:y':None}}
        self.src.write_text(json.dumps(d,ensure_ascii=False))
        ir.build(self.src,self.out)
        self.assertTrue(ir.validate(self.out)['valid'])
        self.assertEqual(ir.lookup(self.out,'1:3')['characters'],'A🙂B')

    def test_no_tree_rejected(self):
        self.src.write_text('{}')
        with self.assertRaisesRegex(ValueError,'Expected'): ir.build(self.src,self.out)

if __name__ == '__main__': unittest.main()
