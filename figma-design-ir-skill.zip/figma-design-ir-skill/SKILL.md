---
name: figma-design-ir
version: 1.0.0
description: Convert Figma REST file or file-nodes JSON into smaller AI-oriented design context without silently losing layout, typography, paint, component, or variable semantics. Use for Figma-to-code, UI reconstruction, design-system extraction, and node-level context retrieval.
---

# Figma Design IR — 保真优先的 API JSON 精简

## 目标
在最少必要上下文中交付足够的设计事实，支持高质量 UI 生成；不以压缩比牺牲正确性。**禁止声称缩减后的单独 JSON 能 100% 还原任意 Figma 文件**：它可能依赖字体文件、图片资产、外部组件、变量模式、渲染器、版本和目标平台。使用不可变原始 JSON 快照 + 可追溯 Compact IR + 依赖查询 + 视觉验收。

## 调用条件
收到 Figma REST `GET /v1/files/:key` 或 `GET /v1/files/:key/nodes?ids=...` 的 JSON，或希望为 AI 提供单个页面/节点的最小设计上下文。

## 不变量（不得违反）
1. 保留原节点 id、type、父子关系、子节点次序；未确认前不得推断组件语义（例如 FRAME → Button）。
2. 所有保留属性必须保留原始类型、数值精度、数组顺序、`null` 与 `false` 差异；禁止擅自归一颜色/尺寸单位或合并文字样式。
3. 为布局保留 Auto Layout（包括 GRID）、wrap、alignment、gap、padding、HUG/FILL/FIXED、min/max、constraints、positioning、overflow、transform、裁剪等源字段；任何未知字段都可以通过 raw snapshot 回查。
4. 为视觉保留 fills、strokes、effects、blend、opacity、corner radii、paint transforms、image refs、geometry/paths 等；需要 `geometry=paths` 才能得到的路径不得假装已提供。
5. 为文本保留 characters、style、逐字符 style overrides、override table、段落/列表、排版/截断和绑定；字体不可用时报告差异。
6. 为组件及 Design Tokens 保留 componentId、组件属性/definitions、styles、boundVariables、explicitVariableModes；无法读取变量定义或解析别名时标记 `unresolved`，不得固化颜色为唯一真值。
7. 语义压缩不等于无损传输：凡 Compact IR 未携带的渲染相关字段必须能从相同 version 的 raw snapshot 回查，否则本次输出不得标记 `full-fidelity-ready`。
8. 未知的新字段、未知节点类型必须 fail-open：原始信息仍可回查，标记待审查；禁止静默删除。
9. 不将 Figma 文件密钥、API token、私密插件数据或本地绝对路径发给不可信模型服务。原始快照可能包含敏感设计内容。
10. 验收需区分：结构/依赖完整性、字段保真、目标平台可表达性、真实渲染视觉差异。仅通过 JSON 校验不代表 UI 像素级一致。

## 处理步骤
1. **锁定来源**：记录 `fileKey`（可脱敏）、`version`、API endpoint、ids/depth/geometry/plugin_data 和抓取时间。若 JSON 的输入为局部节点，禁止声明已覆盖整个文件。
2. **建立不可变快照**：将原 JSON 按内容 SHA-256 哈希存储，不允许丢失原始信息。至少在转换流程中始终可读取它。
3. **选择任务范围**：默认只为目标节点子树提供上下文；对全文件先请求 `depth=2` 探索，再用 `/nodes?ids=...` 获取具体树。注意该 API 可能附带祖先、其他依赖节点；按 id 校验。
4. **生成 Compact IR**：运行 `python scripts/figma_ir.py build INPUT.json -o OUTDIR`。默认保留渲染相关字段的**原始命名/值**、拓扑和元数据引用，剔除非渲染噪声；详细选择规则见 `references/field-policy.md`。
5. **质量门禁**：运行 `python scripts/figma_ir.py validate OUTDIR`。查看 `audit.json` 的 omitted keys、unsupported/unknown fields 和节点统计；出现不认识的字段不能自动认定无关。
6. **分层向 AI 供应上下文**：先提供 `compact.json` 中目标节点与必要祖先，随后依赖要求调取局部详细属性、component/styles/variable definitions、图片及 vector paths；遇到保真歧义用 `lookup` 读取 raw JSON。
7. **资源准备**：使用 image fills endpoint 下载图片；必要时用 image export 或 geometry paths 获取图标/复杂矢量；记录 URL 过期性并将字节保存为本地资产；确认字体/字重/字体回退。组件跨文件时检索源库。
8. **验证**：用原节点的 Figma 导出图作为参考，在目标平台相同视口、缩放、字体环境下渲染对比；分类记录 geometry、typography、paint、assets、variants、responsive 差异，修正后回归。

## 面向 AI 的行为规则
- 先读范围、版本与缺失项；只请求当前任务需要的节点。
- 对布局使用明确的 `layoutMode` / constraints / sizing 字段，不从屏幕坐标反推 Auto Layout。
- 对混合富文本不得只使用 `characters` 和单个 `style`；必须结合 override 映射。
- 遇到图片、矢量、变量引用、未知字段，用原始节点与外部依赖补全；不得编造缺失数据。
- 若没有 `geometry=paths`、assets 或变量定义，只输出“条件化可实现”，不得声称像素级保真。
- 转换器生成的字段都是**源数据子集**，不是所有样式的规范化解释；目标平台映射须单独完成并测试。

## 工程四视角
- DDD：设计节点/组件/变量/资源是不同上下文，保留 id、version 和引用不变量。
- BDD：Given 任意非空有效节点树 When 构建/验证 Then 拓扑和保留字段值可逐节点核实；未知字段必须进审计；缺失节点 id 应拒绝。
- SDD：`compact.json`、`manifest.json`、`audit.json` 为版本化输出契约；字段升级需同步用例。
- TDD：运行 `python -m unittest discover -s tests -v`；新增类型首先加入失败用例，再调整策略；不以构建成功代替渲染验收。

## 交付和失败策略
输出 `compact.json`（减少 AI 上下文）、`raw.json`（原始源不可变快照）、`manifest.json`（范围/哈希/能力）、`audit.json`（遗漏风险）。**compact.json 单独不提供任意设计的完整保真保证**；必须具备 snapshot+按需检索。若 raw 缺失或哈希不匹配，停止任何“保真”声明并重新获取同一版本源数据。

## 官方文档
- https://developers.figma.com/docs/rest-api/file-endpoints/
- https://developers.figma.com/docs/rest-api/file-node-types/
- https://developers.figma.com/docs/rest-api/files/
- https://developers.figma.com/docs/rest-api/variables-types/
- https://developers.figma.com/docs/rest-api/variables-endpoints/
