#!/usr/bin/env python3
"""Conservative Figma REST JSON compactor: never discards the source snapshot."""
import argparse
import copy
import hashlib
import json
import pathlib
import sys

SAFE_METADATA = frozenset(('locked', 'pluginData', 'sharedPluginData', 'exportSettings'))
SCHEMA = 'figma-design-ir/1.0'


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, separators=(',', ':'), sort_keys=False), encoding='utf-8')


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def project(node, audit, seen):
    if not isinstance(node, dict) or not isinstance(node.get('id'), str) or not isinstance(node.get('type'), str):
        raise ValueError('Invalid Figma node: id and type must be strings')
    node_id = node['id']
    if node_id in seen:
        raise ValueError('Duplicate node ID: ' + node_id)
    seen.add(node_id)
    out = {}
    for k, v in node.items():
        if k == 'children':
            if not isinstance(v, list):
                raise ValueError('children is not an array at ' + node_id)
            out[k] = [project(child, audit, seen) for child in v]
        elif k in SAFE_METADATA:
            audit['omitted'].append({'nodeId': node_id, 'field': k, 'reason': 'metadata-only; raw snapshot available'})
        else:
            out[k] = copy.deepcopy(v)
    return out


def build(source, outdir):
    source_bytes = source.read_bytes()
    payload = json.loads(source_bytes)
    if not isinstance(payload, dict):
        raise ValueError('Input must be a JSON object')
    audit = {'omitted': [], 'warnings': [], 'nodeCount': 0}
    seen = set()
    compact = {'schema': SCHEMA, 'kind': None, 'header': {}, 'references': {}, 'document': None, 'nodes': None}
    if isinstance(payload.get('document'), dict):
        compact['kind'] = 'file'
        compact['document'] = project(payload['document'], audit, seen)
    elif isinstance(payload.get('nodes'), dict):
        compact['kind'] = 'nodes'
        projected = {}
        for node_id, entry in payload['nodes'].items():
            if entry is None:
                projected[node_id] = None
                audit['warnings'].append('Requested node is null: ' + node_id)
                continue
            if not isinstance(entry, dict) or not isinstance(entry.get('document'), dict):
                raise ValueError('Invalid nodes entry: ' + node_id)
            # Nodes endpoint can contain overlapping subtrees. Dedup is scoped per entry.
            scoped = set()
            projected[node_id] = {k: project(v, audit, scoped) if k == 'document' else copy.deepcopy(v)
                                  for k, v in entry.items()}
            seen.update(scoped)
        compact['nodes'] = projected
    else:
        raise ValueError('Expected a Figma file response (document) or nodes response (nodes)')
    compact['references'] = {k: copy.deepcopy(payload[k]) for k in ('components', 'componentSets', 'styles') if k in payload}
    compact['header'] = {k: copy.deepcopy(v) for k, v in payload.items()
                         if k not in ('document', 'nodes', 'components', 'componentSets', 'styles')}
    audit['nodeCount'] = len(seen)
    audit['warnings'].append('This package does not contain image bytes, fonts, resolved variables, or missing vector paths unless supplied separately.')
    outdir.mkdir(parents=True, exist_ok=True)
    # raw.json is a verbatim copy, including whitespace and original JSON order.
    (outdir / 'raw.json').write_bytes(source_bytes)
    dump(outdir / 'compact.json', compact)
    manifest = {'schema': SCHEMA, 'sourceSha256': sha256_bytes(source_bytes),
                'compactSha256': sha256_bytes((outdir / 'compact.json').read_bytes()),
                'sourceVersion': payload.get('version'), 'kind': compact['kind'],
                'rawSnapshotRequiredForFullFidelity': True,
                'status': 'needs-external-dependencies-and-render-validation'}
    dump(outdir / 'manifest.json', manifest)
    dump(outdir / 'audit.json', audit)
    return manifest, audit


def validate(outdir):
    raw_bytes = (outdir / 'raw.json').read_bytes()
    compact_bytes = (outdir / 'compact.json').read_bytes()
    manifest = json.loads((outdir / 'manifest.json').read_text(encoding='utf-8'))
    audit = json.loads((outdir / 'audit.json').read_text(encoding='utf-8'))
    if sha256_bytes(raw_bytes) != manifest['sourceSha256'] or sha256_bytes(compact_bytes) != manifest['compactSha256']:
        raise ValueError('Hash mismatch: raw or compact modified')
    raw = json.loads(raw_bytes)
    compact = json.loads(compact_bytes)
    if compact.get('schema') != SCHEMA:
        raise ValueError('Schema mismatch')
    comparison = {'omitted': []}
    seen = set()
    if 'document' in raw:
        expected = project(raw['document'], comparison, seen)
        if expected != compact['document'] or compact['kind'] != 'file':
            raise ValueError('Node tree/value mismatch')
    else:
        if compact['kind'] != 'nodes':
            raise ValueError('Kind mismatch')
        for k, entry in raw['nodes'].items():
            if entry is None:
                if compact['nodes'].get(k, 'MISSING') is not None:
                    raise ValueError('Null entry mismatch: ' + k)
            else:
                local_seen = set()
                expected = project(entry['document'], comparison, local_seen)
                got = compact['nodes'][k]
                if got.get('document') != expected or {x:y for x,y in got.items() if x != 'document'} != {x:y for x,y in entry.items() if x != 'document'}:
                    raise ValueError('Node entry mismatch: ' + k)
    for k in ('components', 'componentSets', 'styles'):
        if k in raw and compact['references'].get(k) != raw[k]:
            raise ValueError('Reference mismatch: ' + k)
    if compact['header'] != {k:v for k,v in raw.items() if k not in ('document','nodes','components','componentSets','styles')}:
        raise ValueError('Header mismatch')
    if comparison['omitted'] != audit['omitted']:
        raise ValueError('Audit mismatch')
    return {'valid': True, 'sourceVersion': manifest.get('sourceVersion'),
            'nodeCount': audit['nodeCount'], 'omittedMetadataFields': len(audit['omitted']),
            'renderValidated': False}


def lookup(outdir, node_id):
    raw = json.loads((outdir / 'raw.json').read_text(encoding='utf-8'))
    def walk(node):
        if not isinstance(node, dict):
            return None
        if node.get('id') == node_id:
            return node
        for child in node.get('children', []):
            result = walk(child)
            if result is not None:
                return result
        return None
    if 'document' in raw:
        return walk(raw['document'])
    for entry in raw.get('nodes', {}).values():
        if entry and (res := walk(entry.get('document'))) is not None:
            return res
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('build'); p.add_argument('input', type=pathlib.Path); p.add_argument('-o', '--outdir', required=True, type=pathlib.Path)
    p = sub.add_parser('validate'); p.add_argument('outdir', type=pathlib.Path)
    p = sub.add_parser('lookup'); p.add_argument('outdir', type=pathlib.Path); p.add_argument('node_id')
    args = parser.parse_args()
    try:
        if args.command == 'build':
            m, a = build(args.input, args.outdir)
            result = {'manifest': m, 'nodeCount': a['nodeCount'], 'omittedMetadataFields': len(a['omitted'])}
        elif args.command == 'validate':
            result = validate(args.outdir)
        else:
            result = lookup(args.outdir, args.node_id)
            if result is None:
                raise ValueError('Node not found: ' + args.node_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as error:
        print('ERROR:', error, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
