# Field policy (v1)

## 分类
- **identity/tree**: `id`, `type`, `name`, `children`：保持。
- **render-capable**: 除下面 `SAFE_METADATA` 中有限字段以外，节点所有其他属性原样保留；包括将来新增的布局、字体、色彩字段。这是 v1 的保守策略。
- **metadata-only**: `locked`, `pluginData`, `sharedPluginData`, `exportSettings`：可以从 compact 中省略，但原始快照必须保留；注意 exportSettings 会影响导出行为，任务涉及导出时必须回查。
- **file header**: `document`、`nodes` 中的树做最小投影；全文件 `styles`, `components`, `componentSets` 在 `references` 中完整携带，以防引用丢失；其余顶层元数据放 `header`，仅明确噪声字段可过滤。

## 为什么保守？
新 Figma REST 节点字段可能影响布局或外观。不存在未来兼容且被官方保证“永远可以删除”的全面字段名单。对未知字段默认保留才不会静默丢失新能力。尺寸约束、Grid、变换、混合文本、变量模式、表达式、mask 和矢量 path 不得依赖主观简化。

## 后续压缩的安全门禁
可增加 `medium` / `aggressive` 视图，但仅用于具体生成任务：
1. 对每个删除的字段维护节点 id + JSON pointer + reason；
2. 验证 raw pointer 可用；
3. 保留 dependency closure（组件、变量、图片）；
4. 原始快照与目标版本锁定；
5. 完整性对比和实际渲染验收通过后才允许声称该页面达到指定容差。

## 外部依赖与能力限制
- 变量定义端点受权限、账号方案和文件共享限制； `boundVariables` 本身不等于解析后的值。
- 使用 `geometry=paths` 才能取得相应矢量路径；无 paths 不得声称精确复原矢量。
- 需要单独取得 imageRef 的实际图片字节；图片 URL 有时效。
- 目标字体/操作系统排版差异可能改变布局。
- 动画、交互、Prototype、布尔运算效果不保证仅凭静态文件 JSON 可复原。
