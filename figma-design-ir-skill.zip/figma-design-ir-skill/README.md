# Figma Design IR Skill

Conservative, reversible Figma JSON reduction for AI-assisted UI coding. No external Python dependencies.

```bash
python scripts/figma_ir.py build figma-response.json -o out
python scripts/figma_ir.py validate out
python scripts/figma_ir.py lookup out '1:3'
python -m unittest discover -s tests -v
```

`out/compact.json` is the AI-oriented context; `out/raw.json` stores a byte-for-byte original snapshot. Neither file alone guarantees visually identical rendering without images, fonts, variable definitions and visual comparison.

The current v1 intentionally **does not claim major compression**: it drops only known non-rendering node metadata while preserving all unknown fields. Further schema-specific compression requires test evidence and a recoverable original. Actual savings depend on design structure; compact serialization may reduce whitespace substantially while components and raw references remain intact.

For Codex-like installations, put the `figma-design-ir-skill/` directory in your Skills discovery directory and read/activate `SKILL.md` according to the host's convention.
